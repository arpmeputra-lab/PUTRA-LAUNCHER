package com.putra.launcher;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.Base64;
import android.view.Display;
import android.view.WindowManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.webkit.JavascriptInterface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public final class PutraBridge {
    private final Activity activity;
    private final PackageManager pm;

    public PutraBridge(Activity activity) {
        this.activity = activity;
        this.pm = activity.getPackageManager();
    }

    @JavascriptInterface
    public String getApps() {
        JSONArray out = new JSONArray();
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> entries;
        if (Build.VERSION.SDK_INT >= 33) {
            entries = pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0));
        } else {
            //noinspection deprecation
            entries = pm.queryIntentActivities(intent, 0);
        }
        Collections.sort(entries, Comparator.comparing(
                x -> x.loadLabel(pm).toString().toLowerCase()));

        for (ResolveInfo ri : entries) {
            try {
                String pkg = ri.activityInfo.packageName;
                String label = ri.loadLabel(pm).toString();
                ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                boolean game = Build.VERSION.SDK_INT >= 26
                        && ai.category == ApplicationInfo.CATEGORY_GAME;

                JSONObject row = new JSONObject();
                row.put("n", label);
                row.put("p", pkg);
                row.put("g", game ? 1 : 0);
                row.put("i", drawableToDataUri(ri.loadIcon(pm)));
                out.put(row);
            } catch (Exception ignored) { }
        }
        return out.toString();
    }

    @JavascriptInterface
    public boolean launch(String packageName) {
        try {
            Intent launch = pm.getLaunchIntentForPackage(packageName);
            if (launch == null) return false;
            activity.runOnUiThread(() -> {
                try { activity.startActivity(launch); } catch (Exception ignored) { }
            });
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @JavascriptInterface
    public String getDeviceInfo() {
        JSONObject o = new JSONObject();
        try {
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            ActivityManager am = (ActivityManager) activity.getSystemService(Context.ACTIVITY_SERVICE);
            am.getMemoryInfo(mi);
            o.put("memoryAvailableMb", mi.availMem / (1024L * 1024L));
        } catch (Exception ignored) { }

        try {
            BatteryManager bm = (BatteryManager) activity.getSystemService(Context.BATTERY_SERVICE);
            int level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
            if (level >= 0) o.put("battery", level);
        } catch (Exception ignored) { }

        try {
            WindowManager wm = (WindowManager) activity.getSystemService(Context.WINDOW_SERVICE);
            Display display = wm.getDefaultDisplay();
            float hz = display.getRefreshRate();
            if (hz > 0) o.put("refreshRate", Math.round(hz));
        } catch (Exception ignored) { }

        if (Build.VERSION.SDK_INT >= 29) {
            try {
                PowerManager power = (PowerManager) activity.getSystemService(Context.POWER_SERVICE);
                o.put("thermalStatus", thermalName(power.getCurrentThermalStatus()));
            } catch (Exception ignored) { }
        }
        return o.toString();
    }

    @JavascriptInterface
    public void openDisplaySettings() {
        activity.runOnUiThread(() -> {
            try {
                activity.startActivity(new Intent(Settings.ACTION_DISPLAY_SETTINGS));
            } catch (Exception ignored) { }
        });
    }

    @JavascriptInterface
    public void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(activity)) {
            activity.runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + activity.getPackageName()));
                    activity.startActivity(i);
                } catch (Exception ignored) { }
            });
        }
    }

    private static String thermalName(int status) {
        switch (status) {
            case 0: return "NORMAL";
            case 1: return "LIGHT";
            case 2: return "MODERATE";
            case 3: return "SEVERE";
            case 4: return "CRITICAL";
            case 5: return "EMERGENCY";
            case 6: return "SHUTDOWN";
            default: return "UNKNOWN";
        }
    }

    private String drawableToDataUri(Drawable d) {
        int w = Math.max(1, Math.min(192, d.getIntrinsicWidth()));
        int h = Math.max(1, Math.min(192, d.getIntrinsicHeight()));
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        d.setBounds(0, 0, w, h);
        d.draw(c);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.PNG, 100, out);
        b.recycle();
        return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }
}
