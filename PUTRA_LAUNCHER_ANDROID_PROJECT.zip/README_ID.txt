PUTRA LAUNCHER — PROJECT NATIVE ANDROID

ISI
- app/src/main/assets/index.html : tampilan launcher yang berasal dari HTML kamu.
- PutraBridge.java : daftar aplikasi asli + ikon, menjalankan aplikasi, informasi
  baterai/memori/refresh rate/status thermal, dan membuka pengaturan layar.
- MainActivity.java : WebView yang memuat HTML dan memasang bridge native.
- AndroidManifest.xml : permission visibilitas paket aplikasi dan activity landscape.

CARA BUILD APK
1. Ekstrak ZIP ini.
2. Buka folder PutraLauncherNative di Android Studio.
3. Pastikan Android SDK Platform 35 dan JDK 17 terpasang.
4. Tunggu Gradle Sync selesai.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug akan dibuat di app/build/outputs/apk/debug/app-debug.apk.

BATASAN ANDROID YANG JUJUR
- QUERY_ALL_PACKAGES dipakai agar halaman tambah aplikasi dapat membaca launcher
  activities yang terpasang. Distribusi Google Play memiliki aturan pembatasan khusus.
- Android/ROM dapat menyembunyikan sebagian paket; daftar game ditentukan kategori
  game yang dilaporkan aplikasi, bukan tebakan nama.
- Data yang ditampilkan hanya yang disediakan API: RAM tersedia, baterai, refresh
  rate layar, dan status thermal. Ping game dan suhu CPU numerik tidak diklaim.
- Refresh rate: tombol hanya membuka pengaturan layar; pengguna memilih mode yang
  tersedia di perangkat.
- RAM tidak bisa "dibersihkan" paksa oleh aplikasi biasa. Android mengelola memori.
- Mapping sentuhan lintas-game yang sesungguhnya belum diaktifkan pada project ini.
  Itu memerlukan AccessibilityService yang diaktifkan pengguna, UI overlay dan
  pengujian kompatibilitas tiap game/perangkat. Tidak boleh mengklaim sudah aktif.
- Fix Touch tidak bisa mengkalibrasi digitizer Android melalui API publik umum.
  Tes sentuh lokal pada halaman hanya menguji respons sentuhan di halaman launcher.
- Permission QUERY_ALL_PACKAGES sensitif dan tidak otomatis menjamin persetujuan
  Google Play. Untuk instalasi pribadi/sideload, pengguna tetap harus mengizinkan
  pemasangan APK dari sumber tersebut.

KEAMANAN
JavaScript bridge hanya dipasang pada HTML lokal di assets, bukan pada halaman web
eksternal. Jangan mengubah WebView agar membuka situs asing dengan bridge aktif.
